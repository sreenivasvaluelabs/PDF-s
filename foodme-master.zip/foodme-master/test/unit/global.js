'use strict';

beforeEach(module('foodMeApp'));
