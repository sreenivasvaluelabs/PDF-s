'use strict';

foodMeApp.value('localStorage', window.localStorage);
