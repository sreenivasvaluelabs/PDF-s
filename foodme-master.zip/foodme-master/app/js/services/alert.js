'use strict';

foodMeApp.value('alert', window.alert);
