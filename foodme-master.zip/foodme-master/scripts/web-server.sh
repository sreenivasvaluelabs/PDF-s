#!/bin/bash

BASE_DIR=`dirname $0`

node $BASE_DIR/../server/start.js $*
